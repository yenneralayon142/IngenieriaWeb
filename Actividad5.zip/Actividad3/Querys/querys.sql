CREATE TABLE registro (
    id INT AUTO_INCREMENT PRIMARY KEY, 
    nombre VARCHAR(50),
    apellido VARCHAR(50),
    edad  INT(20),
    ciudad VARCHAR(50),
    celular BIGINT(11),
    usuario VARCHAR(50),
    pass VARCHAR(50) 
);

CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario VARCHAR(50),
    pass VARCHAR(50)
);


dataUsabilidad



 